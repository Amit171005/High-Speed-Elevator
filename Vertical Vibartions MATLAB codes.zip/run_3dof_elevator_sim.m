%==========================================================================
% MAIN SCRIPT: 3-DOF High-Speed Elevator (Vertical Isolation)
%
% This version is corrected to use the 'ode15s' stiff solver
% and replaces the 'spectrogram' with a base-MATLAB 'fft' plot.
%==========================================================================

%% --- 1. SCRIPT INITIALIZATION ---
clear;         % Clear workspace variables
clc;           % Clear command window
close all;     % Close all figures
fprintf('Starting 3-DOF (Isolation) elevator simulation...\n');

%% --- 2. DEFINE SYSTEM PARAMETERS (as individual variables) ---
% --- Physical Constants ---
g = 9.81; % Acceleration due to gravity (m/s^2)

% --- Hoistway and Geometry ---
L_total = 200; % Total hoistway height (m)

% --- Mass Properties (3-DOF) ---
m_cabin = 1000; % Mass of passenger cabin + load (kg)
m_frame = 500;  % Mass of the structural car frame/sling (kg)
m_cwt = 2000;   % Mass of counterweight (kg) 

% --- Rope Properties (Stiffness & Damping) ---
AE_hoist = 9e7; % Stiffness property (AE) of hoist ropes (N)
AE_comp  = 7e7; % Stiffness property (AE) of comp. ropes (N)
damping_ratio = 0.02; % Modal damping ratio (zeta) for ropes

% --- Isolation Pad Properties (The core of this model) ---
iso_freq_hz = 3.0; % Target isolation frequency (Hz)
iso_zeta = 0.4;  % Target isolation damping ratio (0.4 = 40%)

omega_iso = iso_freq_hz * (2*pi); % Convert to rad/s
k_iso = omega_iso^2 * m_cabin; % Stiffness (N/m)
c_iso = 2 * iso_zeta * omega_iso * m_cabin; % Damping (Ns/m)

fprintf('Isolation Pads: k_iso = %.0f N/m, c_iso = %.0f Ns/m\n', ...
         k_iso, c_iso);

% --- Drive System (Input Profile) ---
V_max   = 8.0;  % Max constant velocity (m/s)
A_max   = 1.0;  % Max acceleration (m/s^2)
J_max   = 0.8;  % Max jerk (m/s^3)

% --- Disturbance (Motor Ripple) ---
f_ripple = 30;   % Frequency of motor ripple (Hz)
A_ripple = 0.01; % Amplitude of ripple (as velocity disturbance) (m/s)

%% --- 3. SIMULATION SETUP ---
% Get the trip end time
[~, ~, ~, t_trip_end] = get_prescribed_motion(inf, J_max, A_max, V_max, L_total);

t_sim_end = t_trip_end + 2.0; % Add 2s buffer
t_span = [0, t_sim_end];

% Initial Conditions (State Vector S0 - 6x1) ---
S0 = [0; 0; 0; 0; L_total; 0]; % [y,v_cab; y,v_frame; y,v_cwt]

%% --- 4. RUN THE DYNAMIC SIMULATION ---
fprintf('Running ode15s (stiff solver)...\n');
options = odeset('RelTol', 1e-5, 'AbsTol', 1e-6);

[time, S_states] = ode15s(@(t, S) elevator_3dof_EOM(t, S, ...
    g, m_cabin, m_frame, m_cwt, L_total, AE_hoist, AE_comp, ...
    damping_ratio, k_iso, c_iso, ...
    f_ripple, A_ripple, J_max, A_max, V_max), ...
    t_span, S0, options);

fprintf('Simulation complete.\n');

%% --- 5. POST-PROCESSING AND DATA EXTRACTION ---
fprintf('Processing results and generating plots...\n');

% Extract state variables
y_cabin = S_states(:, 1);
v_cabin = S_states(:, 2);
y_frame = S_states(:, 3);
v_frame = S_states(:, 4);

% --- Calculate Ride Comfort Metrics (Acceleration and Jerk) ---
a_cabin = zeros(length(time), 1);
a_frame = zeros(length(time), 1);

for i = 1:length(time)
    dSdt = elevator_3dof_EOM(time(i), S_states(i,:)', ...
        g, m_cabin, m_frame, m_cwt, L_total, AE_hoist, AE_comp, ...
        damping_ratio, k_iso, c_iso, ...
        f_ripple, A_ripple, J_max, A_max, V_max);
    
    a_cabin(i) = dSdt(2); % dSdt(2) is a_cabin
    a_frame(i) = dSdt(4); % dSdt(4) is a_frame
end

% Get the "ideal" prescribed motion for comparison
[y_p, v_p, a_p, ~] = get_prescribed_motion(time, J_max, A_max, V_max, L_total);

% --- Calculate the pure VIBRATION components ---
a_vibration_cabin = a_cabin - a_p;
a_vibration_frame = a_frame - a_p;

% Calculate Jerk *felt by the passenger*
j_cabin = gradient(a_cabin, time);

%% --- 6. GENERATE PLOTS AND FIGURES (with DYNAMIC scaling) ---

% Plot 1: Total Acceleration (The "Squashed" View)
figure('Name', 'Isolation Effectiveness (Total Accel.)', 'NumberTitle', 'off');
plot(time, a_frame, 'r-', 'DisplayName', 'Frame Acceleration (Noisy)');
hold on;
plot(time, a_cabin, 'b-', 'LineWidth', 2, 'DisplayName', 'Cabin Acceleration (Isolated)');
plot(time, a_p, 'k:', 'LineWidth', 1, 'DisplayName', 'S-Curve (Target)');
title('Total Acceleration: Frame vs. Passenger Cabin');
xlabel('Time (s)');
ylabel('Acceleration (m/s^2)');
legend('show', 'Location', 'best');
grid on;
ylim([min(a_p)-0.5, max(a_p)+0.5]); 

% --- PLOT 2 (SCALED): VIBRATION-ONLY ANALYSIS ---
figure('Name', 'Passenger Ride Comfort (Vibration-Only)', 'NumberTitle', 'off');
subplot(2, 1, 1);
plot(time, a_vibration_frame, 'r-', 'DisplayName', 'Frame Vibration');
hold on;
plot(time, a_vibration_cabin, 'b-', 'LineWidth', 2, 'DisplayName', 'Cabin Vibration');
title('VIBRATION ONLY (Total Accel - S-Curve)');
xlabel('Time (s)');
ylabel('Vibration Accel. (m/s^2)');
legend('show');
grid on;
% --- DYNAMIC SCALING ---
data_max = max(max(a_vibration_frame), max(a_vibration_cabin));
data_min = min(min(a_vibration_frame), min(a_vibration_cabin));
padding = (data_max - data_min) * 0.1;
if padding == 0, padding = 0.1; end
ylim([data_min - padding, data_max + padding]);

% --- The Jerk plot ---
subplot(2, 1, 2);
plot(time, j_cabin, 'm-');
title('Total Passenger Cabin Jerk');
xlabel('Time (s)');
ylabel('Jerk (m/s^3)');
grid on;
% --- DYNAMIC SCALING ---
data_max = max(j_cabin);
data_min = min(j_cabin);
padding = (data_max - data_min) * 0.1;
if padding == 0, padding = 0.5; end
ylim([data_min - padding, data_max + padding]);

% =========================================================================
% === PLOT 3 (MODIFIED): FFT Analysis (No Toolbox Required) ===
% =========================================================================
figure('Name', 'Frequency Analysis (FFT)', 'NumberTitle', 'off');

% --- Find the 'constant velocity' data ---
idx_const_vel = (time > (t_trip_end/2 - 1)) & (a_p == 0);
cabin_vib_cruise = a_vibration_cabin(idx_const_vel);
frame_vib_cruise = a_vibration_frame(idx_const_vel);
time_cruise = time(idx_const_vel);

if ~isempty(time_cruise)
    % --- Calculate FFT parameters ---
    Fs = 1 / mean(diff(time_cruise)); % Calculate Sample Frequency
    L = length(cabin_vib_cruise);     % Length of signal
    
    % --- Calculate FFT for Cabin ---
    Y_cabin = fft(cabin_vib_cruise);
    P2_cabin = abs(Y_cabin/L); % Two-sided spectrum
    P1_cabin = P2_cabin(1:floor(L/2)+1); % Single-sided spectrum
    P1_cabin(2:end-1) = 2*P1_cabin(2:end-1); % Double the amplitude
    
    % --- Calculate FFT for Frame ---
    Y_frame = fft(frame_vib_cruise);
    P2_frame = abs(Y_frame/L);
    P1_frame = P2_frame(1:floor(L/2)+1);
    P1_frame(2:end-1) = 2*P1_frame(2:end-1);
    
    % --- Create frequency axis ---
    f = Fs*(0:floor(L/2))/L;

    % --- Plot the FFT ---
    plot(f, P1_frame, 'r-', 'DisplayName', 'Frame Vibration (Noisy)');
    hold on;
    plot(f, P1_cabin, 'b-', 'LineWidth', 2, 'DisplayName', 'Cabin Vibration (Isolated)');
    title('FFT Snapshot (during Constant Velocity)');
    xlabel('Frequency (Hz)');
    ylabel('Vibration Amplitude (m/s^2)');
    legend('show');
    grid on;
    % --- Appropriate Scaling ---
    xlim([0, f_ripple + 20]); % Zoom to frequencies we care about
    data_max = max(max(P1_frame(f>1)), max(P1_cabin(f>1))); % Find max peak (ignoring 0 Hz)
    if isempty(data_max) || data_max == 0, data_max = 0.1; end
    ylim([0, data_max * 1.2]); % Add 20% padding
else
    fprintf('\nCould not create FFT plot: No constant velocity phase found.\n');
end

%% --- 7. INTERPRET RESULTS (Simplified and Compact) ---
fprintf('\n--- Ride Comfort Analysis Summary (3-DOF Cabin) ---\n');

% Find time indices for the 'constant velocity' phase
% (We already calculated idx_const_vel)
a_vib_cabin_const_vel = a_vibration_cabin(idx_const_vel);

% Calculate the results
if isempty(a_vib_cabin_const_vel)
    max_peak_accel_cabin = NaN;
    rms_accel_cabin = NaN;
else
    max_peak_accel_cabin = max(abs(a_vib_cabin_const_vel));
    rms_accel_cabin = rms(a_vib_cabin_const_vel);
end
max_peak_jerk_cabin = max(abs(j_cabin));

% --- Print the results in a simple list ---
fprintf('Max Peak Vibration (during cruise): %.4f m/s^2\n', max_peak_accel_cabin);
fprintf('Average Rumble (during cruise):   %.4f m/s^2\n', rms_accel_cabin);
fprintf('Max Peak Jerk (entire trip):    %.4f m/s^3\n', max_peak_jerk_cabin);

fprintf('--- End of Simulation ---\n');