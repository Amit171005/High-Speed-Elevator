function dSdt = elevator_3dof_EOM(t, S, ...
    g, m_cabin, m_frame, m_cwt, L_total, AE_hoist, AE_comp, ...
    damping_ratio, k_iso, c_iso, ...
    f_ripple, A_ripple, J_max, A_max, V_max)

% FUNCTION: elevator_3dof_EOM (3-DOF Equations of Motion)
% This function calculates the derivatives of the 6-state vector
% for the 3-DOF (Cabin, Frame, CWT) model.
% STATE VECTOR S:
%   S(1)=y_cabin,S(2) = v_cabin
%   S(3)=y_frame,S(4) = v_frame
%   S(5)=y_cwt,S(6) = v_cwt
% OUTPUT dSdt:
%   dSdt(1) = v_cabin, dSdt(2) = a_cabin
%   dSdt(3) = v_frame, dSdt(4) = a_frame
%   dSdt(5) = v_cwt,   dSdt(6) = a_cwt

%% UNPACK PARAMETERS AND STATE VECTOR 
zeta = damping_ratio; % rename for simplicity
% Unpack 6-state vector S
y_cabin = S(1);
v_cabin = S(2);
y_frame = S(3);
v_frame = S(4);
y_cwt   = S(5);
v_cwt   = S(6);

%% GET PRESCRIBED MOTION (INPUT) 
% Get ideal sheave motion (S-curve)
[y_p, v_p, ~] = get_prescribed_motion(t, J_max, A_max, V_max, L_total);

% Add motor ripple disturbance
v_ripple = A_ripple * sin(2 * pi * f_ripple * t);
v_sheave_car = v_p + v_ripple;
y_sheave_car = y_p; 

% Sheave motion on the counterweight side
v_sheave_cwt = -v_p - v_ripple;
y_sheave_cwt = L_total - y_p;

%% CALCULATE TIME-VARYING PARAMETERS
% Rope Lengths with time
% ROPES ARE ATTACHED TO THE FRAME (y_frame), NOT THE CABIN (y_cabin)
L_hoist_frame = max(1e-3, L_total - y_frame); % Hoist, frame side
L_hoist_cwt   = max(1e-3, L_total - y_cwt);   % Hoist, cwt side
L_comp_frame  = max(1e-3, y_frame);           % Comp, frame side
L_comp_cwt    = max(1e-3, y_cwt);             % Comp, cwt side

% --- Time-Varying Stiffness (k = AE/L) ---
k_hf = AE_hoist / L_hoist_frame;  % Hoist, frame side
k_hcw = AE_hoist / L_hoist_cwt;   % Hoist, cwt side
k_c = 1 / ( (L_comp_frame / AE_comp) + (L_comp_cwt / AE_comp) ); % Comp.

% --- Time-Varying Damping (c = 2*zeta*sqrt(k*m)) ---
c_hf = 2*zeta*sqrt(k_hf * (m_cabin + m_frame));
c_hcw = 2*zeta*sqrt(k_hcw * m_cwt);
c_c = 2*zeta*sqrt(k_c * (m_cabin + m_frame + m_cwt) / 2);

%% CALCULATE FORCES
% Force 1: Isolation Pads (connects Cabin to Frame) 
F_iso = k_iso * (y_frame - y_cabin) + c_iso * (v_frame - v_cabin);
% Force 2: Hoist Ropes (Frame) 
F_hoist_frame = k_hf * (y_sheave_car - y_frame) + c_hf * (v_sheave_car - v_frame);
% Force 3: Hoist Ropes (CWT)
F_hoist_cwt = k_hcw * (y_sheave_cwt - y_cwt) + c_hcw * (v_sheave_cwt - v_cwt);
% Force 4: Compensation Ropes (connects Frame to CWT) 
F_comp = k_c * (y_frame - y_cwt) + c_c * (v_frame - v_cwt);

%Force 5: Gravitational Forces
F_grav_cabin = m_cabin * g;
F_grav_frame = m_frame * g;
F_grav_cwt   = m_cwt * g;

%% CALCULATE ACCELERATIONS (3 EOMs)
% EOM 1: Cabin (m_cabin)
% m*a = F_iso - F_gravity
a_cabin = (1 / m_cabin) * (F_iso - F_grav_cabin);

% EOM 2: Frame (m_frame)
% m*a = F_hoist - F_iso(reaction) - F_comp - F_gravity
a_frame = (1 / m_frame) * (F_hoist_frame - F_iso - F_comp - F_grav_frame);

% EOM 3: Counterweight (m_cwt)
% m*a = F_hoist_cwt + F_comp(reaction) - F_gravity
a_cwt = (1 / m_cwt) * (F_hoist_cwt + F_comp - F_grav_cwt);

%% PACK THE DERIVATIVE VECTOR
dSdt = zeros(6, 1);
dSdt(1) = v_cabin;
dSdt(2) = a_cabin;
dSdt(3) = v_frame;
dSdt(4) = a_frame;
dSdt(5) = v_cwt;
dSdt(6) = a_cwt;

end