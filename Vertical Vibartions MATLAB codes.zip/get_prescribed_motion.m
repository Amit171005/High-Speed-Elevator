function [y_p, v_p, a_p, t_trip_end] = get_prescribed_motion(t_in, ...
    J_max, A_max, V_max, L_total)
%==========================================================================
% FUNCTION: get_prescribed_motion (CORRECTED)
%
% This function calculates the prescribed "S-curve" (constant jerk)
% motion profile at any given time t.
% This version is bug-free.
%==========================================================================

% --- Calculate Time Intervals for 7-Stage Profile ---
t_jerk = A_max / J_max;
t_accel = V_max / A_max;

if (V_max * J_max < A_max^2) % Triangular velocity profile
    t_jerk = sqrt(V_max / J_max);
    t_accel = 2 * t_jerk;
else % Trapezoidal velocity profile
    t_accel = (V_max / A_max) + (A_max / J_max);
end

d_accel = (V_max / 2) * (t_accel + (V_max/A_max));
d_decel = d_accel;
d_const_vel = L_total - d_accel - d_decel;

if d_const_vel < 0
   d_const_vel = 0;
end

t_const_vel = d_const_vel / V_max;

% --- Define the 7 Time Stage boundaries ---
t1 = t_jerk;
t2 = t_accel - t_jerk;
t3 = t_accel;
t4 = t_accel + t_const_vel;
t5 = t4 + t_jerk;
t6 = t4 + t_accel - t_jerk;
t7 = t4 + t_accel;
t_trip_end = t7;

% If the *only* input is 'inf', just return the end time and exit.
if (isinf(t_in(1)))
    y_p = t_trip_end; v_p = 0; a_p = 0;
    return;
end

% --- Pre-calculate all end-of-stage kinematic values ---
% This ensures all variables (v1, y1, v2, y2, etc.) are
% in scope *before* the loop starts, fixing the bugs.

% End of Stage 1 (t=t1)
v1 = 0.5 * J_max * t1^2;
y1 = (1/6) * J_max * t1^3;

% End of Stage 2 (t=t2)
a2 = A_max;
v2 = v1 + A_max * (t2 - t1);
y2 = y1 + v1 * (t2 - t1) + 0.5 * A_max * (t2 - t1)^2;

% End of Stage 3 (t=t3)
v3 = v2 + A_max * (t3 - t2) - 0.5 * J_max * (t3 - t2)^2; % should be V_max
y3 = y2 + v2 * (t3 - t2) + 0.5 * A_max * (t3 - t2)^2 - (1/6) * J_max * (t3 - t2)^3;

% End of Stage 4 (t=t4)
y4 = y3 + V_max * (t4 - t3);

% End of Stage 5 (t=t5)
v5 = V_max - 0.5 * J_max * (t5 - t4)^2;
y5 = y4 + V_max * (t5 - t4) - (1/6) * J_max * (t5 - t4)^3;

% End of Stage 6 (t=t6)
a6 = -A_max;
v6 = v5 - A_max * (t6 - t5);
y6 = y5 + v5 * (t6 - t5) - 0.5 * A_max * (t6 - t5)^2;

% --- Pre-allocate output arrays ---
y_p = zeros(size(t_in));
v_p = zeros(size(t_in));
a_p = zeros(size(t_in));

% --- Main Loop: Calculate p, v, a for each time in t_in ---
for i = 1:length(t_in)
    t = t_in(i);
    
    % --- Stage 1: Constant Positive Jerk (0 to t1) ---
    if (t >= 0 && t < t1)
        a_p(i) = J_max * t;
        v_p(i) = 0.5 * J_max * t^2;
        y_p(i) = (1/6) * J_max * t^3;
        
    % --- Stage 2: Constant Acceleration (t1 to t2) ---
    elseif (t >= t1 && t < t2)
        a_p(i) = A_max;
        v_p(i) = v1 + A_max * (t - t1);
        y_p(i) = y1 + v1 * (t - t1) + 0.5 * A_max * (t - t1)^2;
        
    % --- Stage 3: Constant Negative Jerk (t2 to t3) ---
    elseif (t >= t2 && t < t3)
        a_p(i) = a2 - J_max * (t - t2);
        v_p(i) = v2 + A_max * (t - t2) - 0.5 * J_max * (t - t2)^2;
        y_p(i) = y2 + v2 * (t - t2) + 0.5 * A_max * (t - t2)^2 - (1/6) * J_max * (t - t2)^3;

    % --- Stage 4: Constant Velocity (t3 to t4) ---
    elseif (t >= t3 && t < t4)
        a_p(i) = 0;
        v_p(i) = V_max;
        y_p(i) = y3 + V_max * (t - t3);
        
    % --- Stage 5: Constant Negative Jerk (t4 to t5) ---
    elseif (t >= t4 && t < t5)
        a_p(i) = -J_max * (t - t4);
        v_p(i) = V_max - 0.5 * J_max * (t - t4)^2;
        y_p(i) = y4 + V_max * (t - t4) - (1/6) * J_max * (t - t4)^3;
        
    % --- Stage 6: Constant Deceleration (t5 to t6) ---
    elseif (t >= t5 && t < t6)
        a_p(i) = -A_max;
        v_p(i) = v5 - A_max * (t - t5);
        y_p(i) = y5 + v5 * (t - t5) - 0.5 * A_max * (t - t5)^2;

    % --- Stage 7: Constant Positive Jerk (t6 to t7) ---
    elseif (t >= t6 && t < t7)
        a_p(i) = a6 + J_max * (t - t6);
        v_p(i) = v6 + a6 * (t - t6) + 0.5 * J_max * (t - t6)^2;
        y_p(i) = y6 + v6 * (t - t6) + 0.5 * a6 * (t - t6)^2 + (1/6) * J_max * (t - t6)^3;
        
    % --- Stage 8: Stopped at Top ---
    else
        a_p(i) = 0;
        v_p(i) = 0;
        y_p(i) = L_total;
    end
end
end