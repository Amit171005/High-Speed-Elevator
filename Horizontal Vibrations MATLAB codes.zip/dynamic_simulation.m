function dynamic_simulation
    % --- DYNAMIC ANALYSIS COMPARISON (BEFORE & AFTER OPTIMIZATION) ---
    % This script runs two simulations:
    % 1. BEFORE: Using initial parameters from Table 1 [cite: 231]
    % 2. AFTER: Using optimized parameters from Section 5.3 [cite: 724]
    % It then plots both results side-by-side, similar to Fig 4(d) and Fig 14.
    
    clc;
    close all;

    % --- Common Parameters ---
    m = 1535;     % Mass of the car system (kg) [cite: 232]
    J = 8090;     % Moment of inertia of the car (kg*m^2) [cite: 229]
    v = 7.0;      % Elevator speed (m/s) [cite: 210]
    lambda = 5.0; % Wavelength of guide rail deviation (m) [cite: 185]
    A1 = 0.001;   % Amplitude of deviation (1.0 mm)
    tspan = [0, 8]; % Simulation time (s)
    z0 = [0; 0; 0; 0]; % Initial conditions: [y; theta; y_dot; theta_dot]

    
    % =================================================================
    % 1. SIMULATION 1: BEFORE OPTIMIZATION (Initial Parameters)
    % =================================================================
    
    % Initial Parameters from Table 1 [cite: 231]
    k_init = 1e5;      % Initial stiffness (N/m) [cite: 234]
    c_init = 1000;     % Initial damping (N*s/m) [cite: 237]
    l1_init = 2.8;     % Initial l1 (m) [cite: 238]
    l2_init = 3.7;     % Initial l2 (m) [cite: 239]

    % System matrices for "BEFORE" case
    M_init = [m, 0; 0, J];
    C_init = [4*c_init, 2*c_init*(l2_init - l1_init);
              2*c_init*(l2_init - l1_init), 2*c_init*(l1_init^2 + l2_init^2)];
    K_init = [4*k_init, 2*k_init*(l2_init - l1_init);
              2*k_init*(l2_init - l1_init), 2*k_init*(l1_init^2 + l2_init^2)];

    % Run "BEFORE" simulation
    [t_init, z_init] = ode45(@(t,z) elevatorDynamics(t, z, M_init, C_init, K_init, k_init, c_init, l1_init, l2_init, A1, v, lambda), tspan, z0);

    % Post-process "BEFORE" acceleration
    y_ddot_init = zeros(length(t_init), 1);
    for i = 1:length(t_init)
        dzdt = elevatorDynamics(t_init(i), z_init(i,:)', M_init, C_init, K_init, k_init, c_init, l1_init, l2_init, A1, v, lambda);
        y_ddot_init(i) = dzdt(3);
    end
    
    % =================================================================
    % 2. SIMULATION 2: AFTER OPTIMIZATION (Optimized Parameters)
    % =================================================================
    
    % Optimized Parameters from Section 5.3 [cite: 724]
    k_opt = 228.84;   % Optimized stiffness (N/m)
    c_opt = 4754.9;   % Optimized damping (N*s/m)
    L_opt = 6.7;      % Optimized distance (m)
    l2_opt = 3.7;     % l2 was kept constant
    l1_opt = L_opt - l2_opt; % New l1 = 3.0 m

    % System matrices for "AFTER" case
    M_opt = [m, 0; 0, J];
    C_opt = [4*c_opt, 2*c_opt*(l2_opt - l1_opt);
             2*c_opt*(l2_opt - l1_opt), 2*c_opt*(l1_opt^2 + l2_opt^2)];
    K_opt = [4*k_opt, 2*k_opt*(l2_opt - l1_opt);
             2*k_opt*(l2_opt - l1_opt), 2*k_opt*(l1_opt^2 + l2_opt^2)];

    % Run "AFTER" simulation
    [t_opt, z_opt] = ode45(@(t,z) elevatorDynamics(t, z, M_opt, C_opt, K_opt, k_opt, c_opt, l1_opt, l2_opt, A1, v, lambda), tspan, z0);

    % Post-process "AFTER" acceleration
    y_ddot_opt = zeros(length(t_opt), 1);
    for i = 1:length(t_opt)
        dzdt = elevatorDynamics(t_opt(i), z_opt(i,:)', M_opt, C_opt, K_opt, k_opt, c_opt, l1_opt, l2_opt, A1, v, lambda);
        y_ddot_opt(i) = dzdt(3);
    end

    % =================================================================
    % 3. PLOT BOTH GRAPHS
    % =================================================================
    figure('Name', 'Dynamic Analysis: Before vs. After Optimization');

    % --- Plot 1: BEFORE (Figure 4d) ---
    subplot(2, 1, 1);
    plot(t_init, y_ddot_init, 'b');
    title('BEFORE Optimization (Initial Parameters) - [Ref: Fig 4d]');
    xlabel('Time (s)');
    ylabel('Acceleration (m/s^2)');
    grid on;
    ylim([-0.2, 0.2]); % Match y-axis of Fig 4(d) [cite: 281, 295]
    xlim(tspan);
    
    peak_to_peak_init = max(y_ddot_init(t_init > 2)) - min(y_ddot_init(t_init > 2));
    legend(sprintf('Peak-to-Peak (after 2s): %.3f m/s^2', peak_to_peak_init));

    % --- Plot 2: AFTER (Figure 14) ---
    subplot(2, 1, 2);
    plot(t_opt, y_ddot_opt, 'r');
    title('AFTER Optimization (Optimized Parameters) - [Ref: Fig 14]');
    xlabel('Time (s)');
    ylabel('Acceleration (m/s^2)');
    grid on;
    ylim([-0.2, 0.2]); % Use same y-axis for easy comparison
    xlim(tspan);
    
    peak_to_peak_opt = max(y_ddot_opt(t_opt > 2)) - min(y_ddot_opt(t_opt > 2));
    legend(sprintf('Peak-to-Peak (after 2s): %.3f m/s^2', peak_to_peak_opt));

end


% --- NESTED DYNAMICS FUNCTION ---
% This function is used by both simulations
function dzdt = elevatorDynamics(t, z, M, C, K, k_param, c_param, l1, l2, A1, v, lambda)
    % z = [y; theta; y_dot; theta_dot]
    
    % 1. Calculate Excitation Parameters
    w_exc = (2 * pi * v) / lambda;
    t0 = (l1 + l2) / v;
    
    % 2. Unpack State Vector
    X = [z(1); z(2)];
    X_dot = [z(3); z(4)];
    
    % 3. Calculate Time-Varying Excitation (from Equation 13) [cite: 188]
    y1_t = A1 * sin(w_exc * (t + t0));
    y2_t = A1 * sin(w_exc * t);
    
    y1_dot_t = A1 * w_exc * cos(w_exc * (t + t0));
    y2_dot_t = A1 * w_exc * cos(w_exc * t);
    
    % 4. Assemble Excitation Matrix {Q} (from Equation 10) [cite: 150]
    % Note: y3 and y4 are zero per Eq(13) [cite: 188]
    Q1 = (c_param * y1_dot_t + k_param * y1_t) + (c_param * y2_dot_t + k_param * y2_t);
    Q2 = c_param * l2 * (y2_dot_t) - c_param * l1 * (y1_dot_t) + ...
         k_param * l2 * (y2_t) - k_param * l1 * (y1_t);
    Q = [Q1; Q2];
    
    % 5. Calculate State Derivatives
    X_ddot = M \ (Q - C*X_dot - K*X);
    
    % 6. Pack Output Vector
    dzdt = [X_dot(1); X_dot(2); X_ddot(1); X_ddot(2)];
end